package com.coffeepoweredcrew.objectpool;

public class Client {

    public static void main(String[] args) {


    }
}
