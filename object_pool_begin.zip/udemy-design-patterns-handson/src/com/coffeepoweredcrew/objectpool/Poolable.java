package com.coffeepoweredcrew.objectpool;


public interface Poolable {

}
